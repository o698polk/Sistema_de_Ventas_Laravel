<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'EDITAR USUARIO'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<br><br><br><br>
<center>
<h1>EDITAR PRODUCTO</h1>
<img class="logo_banner"src="../../img/icono.jpg" alt="Image 2">
</center>


<?php if(session('user')->roles=='Administrador' ): ?>
<div class="container ">
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

                        <?php endif; ?>

                            <form method="post" action="<?php echo e(route('product.update',$datos->id)); ?>" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="id" value="<?php echo e($datos->id); ?>">
                            <div class="form-group">
                                <label for="nameproduct">Nombre del Producto</label>
                                <input type="text" name="nameproduct" id="nameproduct" class="form-control"  value="<?php echo e($datos->nameproduct); ?>" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="description">Descripcion del Producto</label>
                                <input type="text" name="description" id="description" class="form-control" value="<?php echo e($datos->description); ?>">
                            </div>
                            <div class="form-group">
                                <label for="stock">Stock del Producto</label>
                                <input type="number" id="stock" name="stock" class="form-control" value="<?php echo e($datos->stock); ?>" required>
                            </div>
                            <div class="form-group">
                            <label for="price">Precio</label>
                            <input type="number" name="price" id="price" step="0.01" class="form-control"value="<?php echo e($datos->price); ?>" >
                            </div>
                            <div class="form-group">
                            <label for="imgproduct">Imagen del Producto</label>
                              <input type="file" name="imgproduct" id="imgproduct" class="form-control">
                         </div>
                         <?php  $user = session('user') ?>
                         <div class="form-group">

                            <input type="hidden" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo $user->__get('id');?>"required style="display: none;"readonly>
                            </div>

                            <div class="form-group">
                            <button type="submit" class="btn btn-primary">EDITAR</button>
                            </div>
                            </form>
                        <a href="<?php echo e(route('product.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>




  </tbody>
</table>
</div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polk Vernaza\Documents\InfoCode\PHP\proyectos\pasteleria\project\resources\views/product/edit.blade.php ENDPATH**/ ?>