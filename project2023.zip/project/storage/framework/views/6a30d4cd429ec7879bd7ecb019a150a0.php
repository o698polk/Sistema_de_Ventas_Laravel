<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'CARRITO DE COMPRAS'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style ">
<br>  <br>  <br>  <br>
<center>
<h1>CARRITO DE COMPRAS</h1>
<img class="logo_banner"src="img/icono.jpg" alt="Image 2">
</center>
</div>
<br><!--
<form method="POST"  action="<?php echo e(route('buscarproducto')); ?>" >
    <?php echo csrf_field(); ?>
    <div class="form-group">

        <input type="text" name="filtro_nombre" placeholder="Nombre" class="form-control" >
    </div>

   
    <button type="submit" class="btn btn-info">Buscar</button>
</form>

-->

<button onclick="imprimirDiv()" class="btn btn-success">Imprimir</button>


<div class="container scrollable-div"id="reportid">
<table class="table boder_bar btn_modulos">
  <thead>
    <tr>
      <th>ID</th>
      <?php if(session('user')->roles=='Administrador' ): ?>
      <th>Nombre del Cliente</th>
      <?php endif; ?>
      <th>Productos</th>
      <th>Imagenes</th>
      <th>Precio</th>
      <th>Disponible</th>
      <th>Ordenar</th>
      <th>Editar</th>
     <th>Eliminar</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($dato->Usuario['id']==session('user')->id && $dato->status==0  ): ?>
    <tr>
      <td><?php echo e($dato['id']); ?></td>
      <?php if(session('user')->roles=='Administrador' ): ?>
      <td><?php echo e($dato->Usuario['nombre_apellido']); ?></td>
      <?php endif; ?>
      <td><?php echo e($dato->Product['nameproduct']); ?></td>
      <td> <img src="<?php echo e($dato->Product['imgproduct']); ?>" alt="avatar"
              class="rounded-circle img-fluid  logo_banner" ></td>

       <td>$<?php echo e($dato->Product['price']); ?></td>
       <?php if($dato->Product['stock']==0 ): ?>
       <td style="color:red;">No disponible</td>
       <?php else: ?>
       <td><?php echo e($dato->Product['stock']); ?></td>
       <?php endif; ?>
      <td><?php echo e($dato['created_at']); ?></td>
      <?php if($dato->Product['stock']>0 ): ?>
      <td><a  class="btn btn-primary" href="<?php echo e(route('ordertcreate',$dato['id'])); ?>">Generar Orden</a></td>
      <?php else: ?>
      <td><a  class="btn btn-secondary" >No disponible</a></td>
      <?php endif; ?>
      <td>
        <form class="deleteForm" action="<?php echo e(route('trolley.destroy',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Eliminar</button>
        </form>
     </td>
    </tr>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($datos->links()); ?>

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\astud\OneDrive\Escritorio\TESIS\PASTELERIA\project\resources\views/trolley/index.blade.php ENDPATH**/ ?>