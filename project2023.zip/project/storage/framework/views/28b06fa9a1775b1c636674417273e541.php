<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FACTURA DE CONFIRMACION</title>
</head>
<body>
    <center>
<div class="container">

        <h1>FACTURA DE CONFIRMACION REVISA LA FACTURA EN LA PAGINA </h1>
          <h2>Nombre de cliente:<?php echo e($dato->cliente['nombre_apellido']); ?></h2>
        
     
           <h3>$<?php echo e($dato['pricetotal']); ?></h3>
            <h3>Sweet and Donuts</h3>
 
   <div class="container" >
            <h3> Fecha </h3>
            <h3><strong> <?php echo e($dato['created_at']); ?> </strong></h3>
            <h3><strong>Estado:</strong>  <?php if($dato['status']=="Order"): ?>  
                TU PEDIDO ESTA RECIEN CREADO, ESTA PENDIENTE A REVISION.
          <?php endif; ?>
          <?php if($dato['status']=="Sent"): ?>  
        TU PEDIDO VA EN CAMINO, YA FUE ENVIADO
  
        <?php endif; ?>
        <?php if($dato['status']=="Completed"): ?>  
       TU PEDIDO FUE ENTREGADO
        <?php endif; ?>
        <?php if($dato['status']=="repayment"): ?>  
      TU PEDIDIO ESTA CANCELADO
        <?php endif; ?></h3>

            <div class="container">
                       <h3>Repartidor:</h3>
                        <h3>  <strong><?php echo e($dato->repartido['nombre_apellido']); ?></strong></h3>
                        <h3><?php echo e($dato->repartido['address']); ?></h3>
                        <h3>Email: <?php echo e($dato->repartido['correo']); ?></h3>
                        <h3>Phone: <?php echo e($dato->repartido['phones']); ?></h3>
        
                        <h3 >Cliente:</h3>
                        <h3> <strong><?php echo e($dato->cliente['nombre_apellido']); ?></strong></h3>
                        </h3><?php echo e($dato->cliente['address']); ?></h3>
                        <h3>Email: <?php echo e($dato->cliente['correo']); ?></h3>
                        <h3>Phone: <?php echo e($dato->cliente['phones']); ?></h3>
             </div>

                <div class="container">
            
                     <h2><strong>Precio Unitario</strong></h2>  
                             
                     <h3>$<?php echo e($dato->Trolley->product->price); ?></h3>  
                               
                               
                                <strong>x<?php echo e($dato['units']); ?></strong><br>
                                  
                                 <?php
                              
                                $iva = 0.12; // IVA del 12%
                                $precioSinIva = $dato->Trolley->product->price *$dato['units'];
                                $ivacobrar= ($precioSinIva * $iva);
                                $precioConIva = $precioSinIva + ($precioSinIva * $iva);
                                ?>
                                $<?php echo e($precioSinIva); ?>

                                IVA (12%)
                                $<?php echo e($ivacobrar); ?>

                                <h3> <strong>Total</strong></h3>
                                <h3>  <strong>$<?php echo e($precioConIva); ?></strong><h3>
                                    
                            
                </div>  

                    
    </div>
</div>

</center>
</body>
</html><?php /**PATH C:\Users\Polk Vernaza\Documents\InfoCode\PHP\proyectos\pasteleria\project\resources\views/purchaorder/correoenviar.blade.php ENDPATH**/ ?>