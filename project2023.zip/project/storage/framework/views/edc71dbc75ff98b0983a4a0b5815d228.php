<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'ORDENES DE COMPRA'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style ">
<br>  <br>  <br>  <br>
<center>
<h1>ORDENES DE COMPRA</h1>
<img class="logo_banner"src="img/icono.jpg" alt="Image 2">
</center>
</div>
<br><!--
<form method="POST"  action="<?php echo e(route('buscarordenecompras')); ?>" >
    <?php echo csrf_field(); ?>
    <div class="form-group">

        <input type="text" name="filtro_correo" placeholder="Correo" class="form-control" >
    </div>
  
  
    <button type="submit" class="btn btn-info">Buscar</button>
</form>-->


<button onclick="imprimirDiv()" class="btn btn-success">Imprimir</button>
<style>
    .completed {
        background-color: green;
        border-radius:10px;
    }

    .repayment {
        background-color: red;
        border-radius:10px;
    }

    .sent {
        background-color: orange;
        border-radius:10px;
    }

    .order {
        background-color: blue;
        border-radius:10px;
    }
</style>

<div class="container scrollable-div"id="reportid">
<table class="table boder_bar btn_modulos">
  <thead>
    <tr>
      <th>ID</th>
      <th>Pedido</th>
      <th>Decripcion</th>
      <th>Disponibles</th>
      <th>Imagen del Porducto</th>
      <th>Unidades</th>
      <th>Nombre del Cliente</th>
      <th>Telefono del Cliente</th>
      <th>Correo del Cliente</th>
      <th>Direcion de Entrega</th>
      <th>Nombre del Repartidos</th>
      <th>Telefono del Repartido </th>
      <th>Precio a Pagar</th>
      <th>Comprobante del Pago</th>
      <th>Fecha</th>
     
     
      <?php if(session('user')->roles=='Administrador'): ?>
      <th></th>
      <th></th>
      <th></th>
      <?php endif; ?>
     <?php if(session('user')->roles=='Repartidor' || session('user')->roles=='Administrador'): ?>
     <th></th>
     <?php endif; ?>
     <?php if(session('user')->roles=='Cliente' || session('user')->roles=='Administrador'): ?>
     <th></th>
     <?php endif; ?>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $matriz['datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($dato->Usuario['id']==session('user')->id ||session('user')->roles=='Administrador' || $dato->repartido['id'] ==session('user')->id ): ?>
    <tr>
      <td><?php echo e($dato['id']); ?></td>
      <td><?php echo e($dato->Trolley->product->nameproduct); ?></td>
        <td><?php echo e($dato->Trolley->product->description); ?></td>
        <td><?php echo e($dato->Trolley->product->stock); ?></td>
    
      <td> <img src="<?php echo e($dato->Trolley->product->imgproduct); ?>" alt="avatar"
              class="rounded-circle img-fluid  logo_banner" ></td>

       <td><?php echo e($dato['units']); ?></td>
        <td><?php echo e($dato->cliente['nombre_apellido']); ?></td>
     
        <td><?php echo e($dato->cliente['phones']); ?></td>
        <td><?php echo e($dato->cliente['correo']); ?></td>
        <td><?php echo e($dato['address']); ?></td>
        
        <td>

        <form class="deleteForm" action="<?php echo e(route('repartidores',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">  
                       <?php echo method_field('PUT'); ?>
                             <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($dato['id']); ?>">
                   <select name="id_repartidor" id="id_repartidor" class="form-control">
                                    <?php $__currentLoopData = $matriz['repartidor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                                        <option value="<?php echo e($datos->id); ?>"
                                            <?php echo e($dato->repartido['id']== $datos->id ? 'selected' : ''); ?>>
                                            <?php echo e($datos->nombre_apellido); ?>

                                        </option>
                                       
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
  
                                <?php if($dato['status']=="Order"&&session('user')->roles=='Administrador'): ?>
          <button type="submit" class="btn btn-primary">Enviar</button>
          <?php endif; ?>
          </form>
        </td>
        <td><?php echo e($dato->repartido['phones']); ?></td>
        <td><?php echo e($dato['pricetotal']); ?></td>
        <td> <img src="<?php echo e($dato['img_pago']); ?>" alt="avatar"
              class="rounded-circle img-fluid  logo_banner" ></td>
       
              <td>
              <?php if($dato['status']=="Order"): ?>  
                <p  class="order"><?php echo e($dato['created_at']); ?></p>
        <?php endif; ?>
        <?php if($dato['status']=="Sent"): ?>  
        <p  class="sent"><?php echo e($dato['created_at']); ?></p>
  
        <?php endif; ?>
        <?php if($dato['status']=="Completed"): ?>  
        <p  class="completed"><?php echo e($dato['created_at']); ?></p>
        <?php endif; ?>
        <?php if($dato['status']=="repayment"): ?>  
        <p  class="repayment"><?php echo e($dato['created_at']); ?></p>
        <?php endif; ?>
       


              </td>
              <td><a  class="btn btn-primary" href="<?php echo e(route('purchaorder.edit',$dato['id'])); ?>">VER</a></td>



              <td > 
   <form class="deleteForm" action="<?php echo e(route('enviarorden',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">  
   <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
   <select class="form-control" id="status" name="status">
       <?php if($dato['status']=="Order"): ?>  
       <option value="Order" style="background-color: orange; color: orange;" class="order"><?php echo e($dato['status']); ?></option>
        <?php endif; ?>
        <?php if($dato['status']=="Sent"): ?>  
       <option value="Sent" style="background-color: blue;color: blue;" class="sent"><?php echo e($dato['status']); ?></option>
        <?php endif; ?>
        <?php if($dato['status']=="Completed"): ?>  
       <option value="Completed" style="background-color: green; color: green;" class="completed"><?php echo e($dato['status']); ?> </option>
        <?php endif; ?>
        <?php if($dato['status']=="repayment"): ?>  
        <option value="repayment" class="repayment"style="background-color: red; color:red;"><?php echo e($dato['status']); ?> 
      </option>
     
        <?php endif; ?> <?php if(session('user')->roles=='Administrador' && $dato['status']!="Completed" && $dato['status']!="repayment" && $dato['status']!="Sent"): ?>
        <option value="Order" style="background-color: orange; color: orange;" class="order"> Order</option>
        <?php endif; ?>
                                   <?php if(session('user')->roles=='Administrador' && $dato['status']!="Completed" && $dato['status']!="repayment"): ?>
                                    <option value="Sent">Sent</option>
                                    <?php endif; ?>
                              
                                </select>
       

        

        <?php if(session('user')->roles=='Administrador' && $dato['status']!="Completed" && $dato['status']!="repayment" && $dato['status']!="Sent"): ?>
        
     <button type="submit" class="btn btn-primary">Enviar</button>
      <?php endif; ?>
      </form>
      </td>  

     <?php if(session('user')->roles=='Administrador' && $dato['status']!="Completed" && $dato['status']!="Sent"): ?>
      <td>
        <form class="deleteForm" action="<?php echo e(route('purchaorder.destroy',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Eliminar</button>
        </form>
     </td>
     <?php endif; ?>
     <?php if(session('user')->roles=='Repartidor' && $dato['status']=="Sent" || session('user')->roles=='Administrador' && $dato['status']=="Sent" ): ?>
     
     <td>
     <form class="deleteForm" action="<?php echo e(route('completar',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <button type="submit" class="btn btn-primary">Completar</button>
        </form>
    </td>
     <?php endif; ?>

     <?php if($dato['status']=="Order" || session('user')->roles=='Administrador' && $dato['status']=="Sent"): ?>

     <td>
        <form class="deleteForm" action="<?php echo e(route('cancelar',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <button type="submit" class="btn btn-danger">Cancelar</button>
        </form>
     </td>
 
     <?php endif; ?>
    </tr>

    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($matriz['datos']->links()); ?>

</div>

<br>  <br>
<left>
<h4>ESTADO DE COMPRA</h4>


</left>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\astud\OneDrive\Escritorio\TESIS\PASTELERIA\project\resources\views/purchaorder/index.blade.php ENDPATH**/ ?>