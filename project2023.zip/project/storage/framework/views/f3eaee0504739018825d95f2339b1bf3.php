<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'FACTURA'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<br><br><br><br>
<center>
<h1>FACTURA</h1>
<img class="logo_banner"src="../../img/icono.jpg" alt="Image 2">
</center>
<button onclick="imprimirPagina()"  class="btn btn-success">Imprimir</button>

<script>
    function imprimirPagina() {
        window.print();
    }
</script>


<div class="container "id="reportid">
<div class="panel invoice-list">
    <div class="list-group animate__animated animate__fadeInLeft">
      <a href="#" class="list-group-item list-group-item-action active">
        <div class="d-flex w-100 justify-content-between">
          <h5 class="mb-1">Nombre de cliente:<?php echo e($dato->cliente['nombre_apellido']); ?></h5>
          <small><?php echo e($dato['created_at']); ?></small>
        </div>
        <p class="amount mb-0">$<?php echo e($dato['pricetotal']); ?></p>
        <div>Sweet and Donuts</div>
      </a>
     
    </div>
</div>

<div class="main" >
    <div class="container mt-3">
        <div class="card animate__animated animate__fadeIn">
            <div class="card-header">
                Fecha
                <strong><?php echo e($dato['created_at']); ?></strong>
                <span class="float-right"> <strong>Estado:</strong> <?php echo e($dato['status']); ?></span>

            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-6 col-md-6">
                        <h6 class="mb-2">Repartidor:</h6>
                        <div> <td> <img src="../../<?php echo e($dato->repartido['imgprofile']); ?>" alt="avatar"
              class="rounded-circle img-fluid  logo_banner" ></td></div>
                        <div>
                            <strong><?php echo e($dato->repartido['nombre_apellido']); ?></strong>
                        </div>
                        
                        <div><?php echo e($dato->repartido['address']); ?></div>
                        <div>Email: <?php echo e($dato->repartido['correo']); ?></div>
                        <div>Phone: <?php echo e($dato->repartido['phones']); ?></div>
                    </div>

                    <div class="col-6 col-md-6">
                        <h6 class="mb-2">Cliente:</h6>
                        <div> <td> <img src="../../<?php echo e($dato->cliente['imgprofile']); ?>" alt="avatar"
              class="rounded-circle img-fluid  logo_banner" ></td></div>
                        <div>
                            <strong><?php echo e($dato->cliente['nombre_apellido']); ?></strong>
                        </div>
                        
                        <div><?php echo e($dato->cliente['address']); ?></div>
                        <div>Email: <?php echo e($dato->cliente['correo']); ?></div>
                        <div>Phone: <?php echo e($dato->cliente['phones']); ?></div>
                    </div>
                    </div>

                </div>

                <div class="table-responsive-sm">
                    <table class="table table-sm table-striped">
                        <thead>
                            <tr>
                                <th scope="col" width="2%" class="center">#</th>
                                <th scope="col" width="20%">Producto/Servicio</th>
                                <th scope="col" class="d-none d-sm-table-cell" width="50%">Descripción</th>

                                <th scope="col" width="10%" class="text-right">P. Unidad</th>
                                <th scope="col" width="8%" class="text-right">Num.</th>
                                <th scope="col" width="10%" class="text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-left">1</td>
                                <td class="item_name"><?php echo e($dato->Trolley->product->nameproduct); ?></td>
                                <td class="item_desc d-none d-sm-table-cell"><?php echo e($dato->Trolley->product->description); ?></td>

                                <td class="text-right"><?php echo e($dato['units']); ?></td>
                                <td class="text-right"><?php echo e($dato->Trolley->product->price); ?></td>
                                <td class="text-right">$<?php echo e($dato['pricetotal']); ?></td>
                            </tr>
                           
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-5">
                    </div>

                    <div class="col-lg-4 col-sm-5 ml-auto">
                        <table class="table table-sm table-clear">
                            <tbody>
                                <tr>
                                    <td class="left">
                                        <strong>Precio Unitario</strong>
                                    </td>
                                    <td class="text-right bg-light">$<?php echo e($dato->Trolley->product->price); ?></td>
                                </tr>
                                <tr>
                                    <td class="left">
                                        <strong>x<?php echo e($dato['units']); ?></strong>
                                    </td>
                                    <td class="text-right bg-light">  <?php
                              
                                $iva = 0.12; // IVA del 12%
                                $precioSinIva = $dato->Trolley->product->price *$dato['units'];
                                $ivacobrar= ($precioSinIva * $iva);
                                $precioConIva = $precioSinIva + ($precioSinIva * $iva);
                                ?>
                            $<?php echo e($precioSinIva); ?>

                            </td>
                                </tr>
                                <tr>
                                    <td class="left">
                                        <strong>IVA (12%)</strong>
                                    </td>
                                    <td class="text-right bg-light"> $<?php echo e($ivacobrar); ?></td>
                                </tr>
                                <tr>
                                    <td class="left">
                                        <strong>Total</strong>
                                    </td>
                                    <td class="text-right bg-light">
                                        <strong>$<?php echo e($precioConIva); ?></strong>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<div class="footer container-fluid mt-3 bg-light">
    <div class="row">
        <div class="col footer-app">&copy; Todos los derechos reservados · <span class="brand-name"></span></div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\astud\OneDrive\Escritorio\TESIS\PASTELERIA\project\resources\views/purchaorder/edit.blade.php ENDPATH**/ ?>