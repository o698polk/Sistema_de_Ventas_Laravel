<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'EDITAR USUARIO'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<br><br><br><br>
<center>
<h1>EDITAR USUARIO</h1>
<img class="logo_banner"src="../../img/donuuts.ico" alt="Image 2">
</center>


<?php if(session('user')->roles=='Administrador' ): ?>
<div class="container ">
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

                        <?php endif; ?>

                        <form method="post" action="<?php echo e(route('usuarios.update',$datos->id)); ?>" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                             <?php echo csrf_field(); ?>

                             <input type="hidden" name="id" value="<?php echo e($datos->id); ?>">
        <div class="form-group">
            <label for="nombre_apellido">Nombres y Apellidos</label>
            <input type="text" name="nombre_apellido" id="nombre_apellido" class="form-control"  value="<?php echo e($datos->nombre_apellido); ?>">
        </div>
        <div class="form-group">
            <label for="usuario">Nombre de Usuario</label>
            <input type="text" name="usuario" id="usuario" class="form-control" value="<?php echo e($datos->usuario); ?>">
        </div>
    <div class="form-group">
            <label for="correo">Email</label>
            <input type="email" id="correo" name="correo" class="form-control" value="<?php echo e($datos->correo); ?>">
        </div>

        <div class="form-group">
            <label for="clave">Password</label>
            <input type="password" id="clave" name="clave" class="form-control" value="<?php echo e($datos->clave); ?>">
        </div>
        <div class="form-group">
            <label for="dni">CI</label>
            <input type="text" name="dni" id="dni" class="form-control" value="<?php echo e($datos->dni); ?>"maxlength="10" min="10" max="10">
        </div>
        <div class="form-group">
            <label for="phones">Phones</label>
            <input type="text" name="phones" id="phones" class="form-control"value="<?php echo e($datos->phones); ?>" maxlength="10" min="10" max="10">
        </div>
        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" name="address" id="address" class="form-control" value="<?php echo e($datos->address); ?>">
        </div>
          <div class="form-group">
          <label for="roles">Selecciona un Rol:</label>
          <select name="roles" id="roles" class="form-control">
          <option value="<?php echo e($datos->roles); ?>"> <?php echo e($datos->roles); ?></option>
          <option value="Repartidor">Repartidor</option>
          <option value="Cliente">Cliente</option>
          <option value="Administrador">Administrador</option>
     
          </select>
          </div>
                        
        <div class="form-group">
            <label for="account">Account</label>
            <input type="text" name="account" id="account" class="form-control" value="<?php echo e($datos->account); ?>"maxlength="10" min="10" max="10">
        </div>
        <div class="form-group">
            <label for="imgprofile">Imgprofile</label>
            <input type="file" name="imgprofile" id="imgprofile" class="form-control" value="<?php echo e($datos->imgprofile); ?>">
        </div>
    
      
        <div class="form-group">
        <button type="submit" class="btn btn-primary">EDITAR</button>
        </div>
                        </form>
                        <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>




  </tbody>
</table>
</div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polk Vernaza\Documents\InfoCode\PHP\proyectos\pasteleria\project\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>